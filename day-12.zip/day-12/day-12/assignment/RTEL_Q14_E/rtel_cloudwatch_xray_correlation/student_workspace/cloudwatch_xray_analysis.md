# AWS CloudWatch & X-Ray Distributed Trace Correlation Report

## 1. CloudWatch Logs Insights Queries
Document the CloudWatch Logs Insights queries constructed to isolate slow invocations and errors from `cloudwatch_xray_traces.json`:

### Query 1: Extract Cold Starts & Invocations Exceeding 3000ms
```sql
fields @timestamp, @requestId, @duration, @initDuration, @message
| filter @type = "REPORT" and (@duration > 3000 or ispresent(@initDuration))
| sort @timestamp desc
```

### Query 2: Stats Aggregation for Average and Max Latencies
```sql
filter @type = "REPORT"
| stats avg(@duration) as AvgDurationMs, max(@duration) as MaxDurationMs, pct(@duration, 95) as P95DurationMs, avg(@initDuration) as AvgInitDurationMs, count(@requestId) as TotalInvocations
```

### Query 3: Correlate Log Events by X-Ray Trace ID
```sql
fields @timestamp, @logStream, @requestId, @message
| filter @message like /1-6735c028-98fbc12e8412891234567801/ or trace_id = "1-6735c028-98fbc12e8412891234567801"
| sort @timestamp asc
```

---

## 2. AWS X-Ray Segment Waterfall Breakdown
Analyzing trace `1-6735c028-98fbc12e8412891234567801`:

| Segment / Subsegment Name | Type / Target | Duration (ms) | Status Code | Details / Error Message |
|---|---|---|---|---|
| `Initialization` | `ColdStart` (Lambda Runtime Init) | 1250.3 | N/A | Cold start initialization (`sub-init-001`) initializing runtime and DynamoDB client. |
| `DynamoDB:PutItem` | `aws` (Amazon DynamoDB) | 55.0 | 200 | DynamoDB item saved successfully (`sub-dynamodb-002`). |
| `ExternalPaymentGateway:Charge` | `remote` (Partner Payment Service) | 6800.0 | 504 | Fault/Error (`sub-extpay-003`): `java.net.SocketTimeoutException: Read timed out after 6800ms`. |

---

## 3. End-to-End Correlation Summary
Document how CloudWatch log lines correlate with the X-Ray trace:
- **Total Function Duration (from REPORT line):** `8214.22 ms` (Billed Duration: `8215 ms`, matching X-Ray root segment duration of `8214.0 ms`).
- **Initialization Duration (`@initDuration`):** `1250.30 ms` (recorded in the `REPORT` log line for `req-aws-001` and correlated to the `Initialization` cold start subsegment of `1250.3 ms`).
- **Primary Latency Bottleneck Subsegment:** `ExternalPaymentGateway:Charge` (`6800.0 ms`), accounting for approximately **82.8%** of the total invocation time.
- **Root Cause Technical Exception:** `java.net.SocketTimeoutException` (`Read timed out after 6800ms`) wrapped in a `PaymentProviderException` returning an HTTP `504` status code when attempting to connect to the remote partner payment service.

---

## 4. Serverless Optimization Recommendations
1. **Lambda Cold Start Mitigation:**
   - *Recommendation:* Enable **AWS Lambda Provisioned Concurrency** for `checkout-processor` during peak traffic windows to keep execution environments pre-initialized and eliminate the `1250.3 ms` cold start penalty. Additionally, initialize SDK clients (such as the DynamoDB client) outside the main handler function and minimize deployment package size/dependencies.

2. **External Gateway Timeout & Circuit Breaking:**
   - *Recommendation:* Configure aggressive HTTP client connection and read timeouts (e.g., `2000–3000 ms` instead of waiting `6800 ms`), implement **exponential backoff with jitter** for transient retries, and introduce a **circuit breaker pattern** (or asynchronous SQS queue decoupling) so slow partner payment responses fail fast rather than exhausting Lambda concurrency.

3. **Memory & Concurrency Tuning:**
   - *Recommendation:* Increase Lambda memory allocation from `512 MB` (currently peaking at `384–386 MB` usage) to `1024 MB` or `1536 MB`. Because AWS Lambda allocates vCPU proportionally to memory, higher memory accelerates CPU-bound class loading and SSL/TLS handshakes during initialization, while configuring **Reserved Concurrency** prevents downstream payment bottlenecks from starving other critical microservices.

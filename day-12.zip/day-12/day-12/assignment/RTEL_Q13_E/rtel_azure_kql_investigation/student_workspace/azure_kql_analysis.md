# Azure Kusto Query Language (KQL) Exception Tracking Report

## 1. KQL Investigation Queries
Document the primary KQL queries formulated to investigate application errors and failing dependencies from `azure_kql_telemetry.json`:

### Query 1: Filter Failing Requests with Error Details
```kql
requests
| where success == false or toint(resultCode) >= 500
| project timestamp, operation_Id, name, resultCode, duration_ms, cloud_RoleName
| order by timestamp desc
```

### Query 2: Correlate Requests with Unhandled C# Exceptions via Join
```kql
requests
| where success == false
| join kind=inner (
    exceptions
) on operation_Id
| project operation_Id, RequestName = name, resultCode, ExceptionClass = type, MethodName = method, RootCauseMessage = message
```

### Query 3: Dependency Failure Rate & Duration Mapping
```kql
dependencies
| summarize 
    TotalCalls = count(), 
    FailedCalls = countif(success == false), 
    AvgDurationMs = round(avg(duration_ms), 2) 
    by target, type
| extend FailureRatePercent = round((todouble(FailedCalls) / TotalCalls) * 100, 2)
| project target, type, TotalCalls, FailedCalls, FailureRatePercent, AvgDurationMs
```

### Query 4: Time-Series Error Render
```kql
requests
| where success == false
| summarize FailedRequests = count() by bin(timestamp, 1m), resultCode
| render timechart
```

---

## 2. Request-to-Exception Correlation Breakdown
Based on the inner join of `requests` and `exceptions` using `operation_Id`, complete the correlation matrix:

| Operation ID | Request Name | Result Code | Exception Class | Method Name | Root Cause Message |
|---|---|---|---|---|---|
| `op-8921-az` | `POST /api/v2/orders/checkout` | `500` | `System.Data.SqlClient.SqlException` | `OrderRepository.SaveOrderAsync` | Execution Timeout Expired. The timeout period elapsed prior to completion of the operation or the server is not responding. |
| `op-8922-az` | `POST /api/v2/orders/checkout` | `500` | `System.Data.SqlClient.SqlException` | `OrderRepository.SaveOrderAsync` | Execution Timeout Expired. The timeout period elapsed prior to completion of the operation or the server is not responding. |
| `op-8925-az` | `POST /api/v2/orders/checkout` | `504` | `System.Net.Http.HttpRequestException` | `PaymentGatewayClient.AuthorizeCharge` | The remote server returned an error: (504) Gateway Timeout. |

---

## 3. Downstream Dependency Failure Rate Matrix
Summarize dependency calls grouped by target and type:

| Dependency Target | Dependency Type | Total Calls | Failed Calls | Failure Rate (%) | Avg Duration (ms) | Operational Health |
|---|---|---|---|---|---|---|
| `sql-ecommerce-prod.database.windows.net \| OrderDb` | SQL | 2 | 2 | 100% | 3035.0 | Critical / Unhealthy (Timeouts) |
| `https://partner-api.com` | HTTP | 1 | 1 | 100% | 4980.0 | Critical / Unhealthy (504 Gateway Timeout) |
| `redis-cache-prod.redis.cache.windows.net:6380` | Redis | 1 | 0 | 0% | 3.2 | Healthy |
| `://azure.com` | Azure DocumentDB | 1 | 0 | 0% | 12.5 | Healthy |

---

## 4. Root Cause Diagnosis & Alert Rule
1. **Primary Root Cause:**
   - *Failing Component:* `OrderingMicroservice` (specifically `OrderRepository.SaveOrderAsync` interacting with the `OrderDb` SQL database, and `PaymentGatewayClient.AuthorizeCharge` calling the external payment partner API).
   - *Root Cause Explanation:* The e-commerce checkout endpoint (`POST /api/v2/orders/checkout`) is experiencing a 100% failure rate driven by two downstream latency bottlenecks:
     1. **Database Timeouts (HTTP 500):** Calls to the `sp_InsertCustomerOrder` stored procedure on `sql-ecommerce-prod.database.windows.net` exceed the 3,000 ms execution threshold (averaging 3,035 ms), throwing unhandled `SqlException` timeouts.
     2. **Payment Gateway Timeouts (HTTP 504):** Outbound authorization requests to `https://partner-api.com/v1/charge` are hanging for nearly 5 seconds (4,980 ms) before failing with a `504 Gateway Timeout` (`HttpRequestException`).

2. **Azure Monitor Alert Rule Configuration:**
   - *Signal Logic:* Custom Log Search (KQL) monitoring `requests` and `dependencies` where `cloud_RoleName == "OrderingMicroservice"` and `success == false` (or `toint(resultCode) >= 500` / `duration_ms > 2500`).
   - *Threshold & Frequency:* Trigger an alert when failed checkout requests or dependency timeouts exceed **2 occurrences** (or a failure rate **> 5%**) within a **5-minute aggregation window**, evaluated every **1 minute** (Severity 1 - Error).
